#include "game.h"
#include <QMessageBox>

Game::Game() {
    dr = new Drum();

    sc = new screen();

    roundNumber = 1;
    qu1 = qu2 = qu3 = an1 = an2 =an3 = "";

    countWrong = score = 0;
}

Game::~Game() {
    delete dr;
    delete sc;
}

/**
 * @brief Game::nextRound - следующий раунд
 */
void Game::nextRound() {
    if ( roundNumber != 3 ) {
        roundNumber++;

        countWrong = 0;

        this->addInScreen();
    }
}
/**
 * @brief Game::getRoundNumber
 * @return ( int ) roundNumber - вернуть текущий раунд
 */
int Game::getRoundNumber() const {
    return roundNumber;
}

/**
 * @brief Game::getScore
 * @return ( int ) score - вернуть количество очков
 */
int Game::getScore() const {
    return score;
}

/**
 * @brief Game::changeScore
 * @param ( int ) _score - изменить количество очков (прибавить к общему числу переданный параметр)
 */
void Game::changeScore(int _score) {
    score += _score;
}

/**
 * @brief Game::takeQuestions  -  получаем вопросы на три раунда игры - разные
 * @param ( const QString filename ) filename - имя файла с вопросами и ответами
 */
int Game::takeQuestions( const QString filename ) {//"resource/json/jsonQuestions.txt"
    qu = new Questions();
    int rez = qu->readJsonFileQuestion( filename );

    if ( rez == 0 ) {

        qu2 = qu1 = qu->getQuestion();
        an1 = qu->getAnswer( qu1 );

        while ( qu2 == qu1 )
            qu2 = qu->getQuestion();
        an2 = qu->getAnswer( qu2 );

        qu3 = qu2;
        while ( qu3 == qu1 || qu3 == qu2 )
            qu3 = qu->getQuestion();
        an3 = qu->getAnswer( qu3 );
    } else {
        delete qu;
        return rez;
    }

    delete qu;
    return rez;
}

/**
 * @brief Game::takeValueDrum
 * @param ( const QString filename ) filename - имя файла со значениями барабана
 * @return
 */
int Game::takeValueDrum(const QString filename) {//"resource/json/jsonValueDrum.txt"
    return dr->readJsonFileValue( filename );
}

/**
 * @brief Game::addInScreen - добавить вопрос и ответ на экран
 */
void Game::addInScreen() {
    switch( roundNumber ) {
        case 1: {
            sc->setQuestion( qu1 );
            sc->setAnswer( an1 );
        } break;
        case 2: {
            sc->setQuestion( qu2 );
            sc->setAnswer( an2 );
        } break;
        case 3: {
            sc->setQuestion( qu3 );
            sc->setAnswer( an3 );
        } break;
    }
}

/**
 * @brief Game::rotateDrum - вращаем барабан, если выпали очки, то прибавить к общим очкам
 */
void Game::rotateDrum() {
    QString currentValue = dr->rotateDrum();

//    if ( currentValue == "Б" )
//        score  = 0;  //банкрот - обнуляем очки
//    else if ( currentValue == "П" )
//         ;
//    else if ( currentValue == "+" ) {
//        //здесь нужно как вве
//        openLetter( 0 );
//            ;   //можно открыть любую букву
//    }
//    else
//    if ( currentValue != "Б" && currentValue != "П" && currentValue != "+" )
//        changeScore( currentValue.toInt() );
}

/**
 * @brief Game::openLetter - открыть букву, если букв несколько, то откроем все одинаковые
 * @param ( int ) num
 */
void Game::openLetter( int num ) {
    sc->openLetter( num );
}

/**
 * @brief Game::getCurrentValue - вернуть текущее значение барабана
 * @return ( QString ) currentValue - текущее значение барабана
 */
QString Game::getCurrentValue() const {
    //return currentValue;
    return dr->getCurrentValueDrum();
}

/**
 * @brief Game::getQuestion - вернуть вопрос
 * @return ( QString ) qu* - вернуть вопрос текущего раунда
 */
QString Game::getQuestion() const {
    switch ( roundNumber ) {
        case 1: return qu1; break;
        case 2: return qu2; break;
        case 3: return qu3; break;
    }
    return "";
}

/**
 * @brief Game::getAnswer - вернуть ответ
 * @return ( QString ) rezult - вернуть переделанный ответ
 */
QString Game::getAnswer() const {
    QString rezult = "";
    QList< bool > answer_flag = sc->getAnswerFlag() ;
    QString answer = sc->getAnswer();
    int i = 0;

    for ( i = 0; i < answer.length(); i++ ) {
        if ( answer_flag.at(i) == false )
            rezult.append( " _ " );
        else
            rezult.append( " " ).append( answer.at( i ) ).append( " " );
    }

    return rezult;
}
/**
 * @brief Game::getCheckLetter - проверить букву на наличие в ответе
 * @param ( QString ) letter - буква
 * @return ( int )  - количество букв в ответе
 */
int Game::getCheckLetter( QString letter ) const {
    return sc->checkLetter( letter );
}

/**
 * @brief Game::getCheckAnswer
 * @param ( QString ) _answer - ответ
 * @return ( bool ) - true - если правильно
 */
bool Game::getCheckAnswer(QString _answer) const {
    return sc->checkAnswer( _answer );
}

/**
 * @brief Game::getStateAnswer
 * @return ( bool ) - состояние ответа, true - отрыт весь
 */
bool Game::getStateAnswer() const {
    return  sc->getStateAnswer();
}

/**
 * @brief Game::victory - победа
 */
void Game::victory() {
    QString text = "";
    text.append( "Ваш счёт: " ).append( QString::number( this->getScore() ) );

    QMessageBox msg;
    msg.setWindowTitle( "Победа!" );
    msg.setInformativeText( text );
    msg.setStandardButtons( QMessageBox::Ok );
    msg.exec();

    if ( roundNumber != 3 )
        this->nextRound();
}

/**
 * @brief Game::defeat - поражение
 */
void Game::defeat() {
    QString text = "";
    text.append( "Вы проиграли " );

    QMessageBox msg;
    msg.setWindowTitle( "Поражение!" );
    msg.setInformativeText( text );
    msg.setStandardButtons( QMessageBox::Ok );
    msg.exec();
}

/**
 * @brief Game::plusCountWrong - увеличить количество неправильных попыток на 1
 */
void Game::plusCountWrong() {
    if ( countWrong != 3 )
        countWrong++;
}

/**
 * @brief Game::getCountWrong
 * @return ( int ) countWrong - количество неправильных попыток
 */
int Game::getCountWrong() const {
    return countWrong;
}
