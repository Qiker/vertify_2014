#ifndef WONDERLANDWINDOW_H
#define WONDERLANDWINDOW_H

#include <QMainWindow>

#include "game.h"

namespace Ui {
class WonderlandWindow;
}

class WonderlandWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit WonderlandWindow(QWidget *parent = 0);
    ~WonderlandWindow();

private slots:
    void on_buttonRotateDrum_clicked();

    void on_buttonEnter_clicked();

private:
    Ui::WonderlandWindow *ui;
    Game *game;
};

#endif // WONDERLANDWINDOW_H
