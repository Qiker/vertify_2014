#include "questions.h"

Questions::Questions() {
    timeRand = QTime( 0, 0, 0 );
    qsrand( timeRand.secsTo( QTime::currentTime() ) );
}

/**
 * @brief Questions::readJsonFileQuestion
 * @param ( const QString ) filename - имя файла, в котором хранятся вопросы и ответы
 * @return ( int ) 0 - Файл открыт и прочитан корректно
 * @return ( int ) 1 - Файл открыт и прочитан некорректно
 * @return ( int ) 2 - Такого файла нет
 */
int Questions::readJsonFileQuestion( const QString filename ) {
    QFile json( filename );
    if ( json.open( QIODevice::ReadOnly ) )
    {
        QJsonParseError parseError;
        QJsonDocument jsonDoc = QJsonDocument::fromJson( json.readAll(), &parseError );
        if ( parseError.error == QJsonParseError::NoError )
        {
            //if ( jsonDoc.isObject() ) {
                parseJsonObjectQuestion( jsonDoc.object() );
            //}
        } else return 1;
        json.close();
    } else  return 2;
    return 0;
}

/**
 * @brief Questions::parseJsonObjectQuestion
 * @param ( QJsonObject )jsonObj - объект, в котором хранится считанная json-конструкция
 * @return ( int )0 - если такой объект существует, и его пытались обработать
 * @return ( int )1 - если такой объект не существует
 */
int Questions::parseJsonObjectQuestion( QJsonObject jsonObj ) {
    if ( !jsonObj.isEmpty() ) {
        QJsonObject::iterator it;
        for ( it = jsonObj.begin(); it != jsonObj.end(); it++ )
            listQuestions.insert( it.key() , it.value().toString() );
        return 0;
    }
    return 1;
}

/**
 * @brief Questions::getQuestion
 * @return ( QString ) - случайный вопрос, если список пуст, то вернется пустота
 */
QString Questions::getQuestion() {
    if ( !listQuestions.isEmpty() ) {
        int i = 0, n = listQuestions.size();
        n = (qrand() % n + 1);

        QHashIterator < QString, QString > it( listQuestions );

        while ( it.hasNext() ) {
            it.next();
            if ( i != n )
                i++;
            else break;
        }

        return it.value();//listQuestions.value( (qrand() % n + 1) );
    } else
        return "";
}
/**
 * @brief Questions::getAnswer
 * @param ( QString ) question - вопрос
 * @return ( QString ) - вернет ответ на впорос, если ответа нет, то вернет пустоту
 */
QString Questions::getAnswer(QString question) {
    if ( !listQuestions.isEmpty() ) {

        QHashIterator < QString, QString > it( listQuestions );
        while ( it.hasNext() ) {
            it.next();
            if ( it.value() == question )
                return it.key();
        }

        return "";
    } else
        return "";
}
