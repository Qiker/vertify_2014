#include "wonderlandwindow.h"
#include "ui_wonderlandwindow.h"

#include <QMessageBox>

WonderlandWindow::WonderlandWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::WonderlandWindow)
{
    ui->setupUi(this);

    game = new Game();

    //тут проверку
    game->takeQuestions( "resource/json/jsonQuestions.txt" );
    game->takeValueDrum( "resource/json/jsonValueDrum.txt" );
    game->addInScreen();  //добавить на экран вопрос и ответ текущего раунда

    QString round = "Раунд ";
    round.append( QString::number( game->getRoundNumber() ) );
    ui->labelNumberRound->clear();
    ui->labelNumberRound->setText( round );

    ui->labelQuestion->clear();
    ui->labelQuestion->setText( game->getQuestion() );

    ui->labelAnswer->clear();
    ui->labelAnswer->setText( game->getAnswer() );

    ui->buttonEnter->setEnabled( false );
    ui->enterCommand->setEnabled( false );
}

WonderlandWindow::~WonderlandWindow()
{
    delete ui;
    delete game;
}

//вращаем барабан
void WonderlandWindow::on_buttonRotateDrum_clicked() {
    game->rotateDrum();

    ui->labelCurrentValueDrum->clear();
    ui->labelCurrentValueDrum->setText( game->getCurrentValue() );

    if ( game->getCurrentValue() == "Б" ) {
        game->changeScore( (-1) * game->getScore() );
        ui->labelScore->clear();
        ui->labelScore->setText( QString::number( game->getScore() ) );
    }

    if ( game->getCurrentValue() == "П" ) {
        QMessageBox msg;
        msg.setWindowTitle( "Сектор приз на барабане" );
        msg.setText( "Возьмете приз?" );
        msg.setStandardButtons( QMessageBox::Yes | QMessageBox::No );

        int n = msg.exec();
        if (n == QMessageBox::Yes) {
          //Нажата кнопка Yes
          game->victory();
          QString round = "Раунд ";
          round.append( QString::number( game->getRoundNumber() ) );
          ui->labelNumberRound->clear();
          ui->labelNumberRound->setText( round );

          ui->labelQuestion->clear();
          ui->labelQuestion->setText( game->getQuestion() );

          ui->labelAnswer->clear();
          ui->labelAnswer->setText( game->getAnswer() );
        } else {
            game->changeScore( 2000 );
            ui->labelScore->clear();
            ui->labelScore->setText( QString::number( game->getScore() ) );

            ui->buttonEnter->setEnabled( true );
            ui->buttonRotateDrum->setEnabled( false );
            ui->enterCommand->setEnabled( true );
        }
    }

//    ui->labelScore->clear();
//    ui->labelScore->setText( QString::number( game->getScore() ) );

    if ( game->getCurrentValue() != "Б" ) {
        ui->buttonEnter->setEnabled( true );
        ui->buttonRotateDrum->setEnabled( false );
        ui->enterCommand->setEnabled( true );
    }
}

//ввод значения
void WonderlandWindow::on_buttonEnter_clicked() {
    QString val = game->getCurrentValue();
    if ( val == "+" && !ui->enterCommand->text().isEmpty() ) {
        game->openLetter( ui->enterCommand->text().toInt() );
        ui->labelAnswer->clear();
        ui->labelAnswer->setText( game->getAnswer() );
        ui->enterCommand->clear();
    }

    if ( val != "+" && val != "П"
         && val != "Б" && ui->enterCommand->text().length() == 1 ) {
        int count = 0;
        count = game->getCheckLetter( ui->enterCommand->text() );
        if ( count == 0 ) {
            if ( game->getCountWrong() != 3 )
                game->plusCountWrong();
            else
                game->defeat();
        }
        else {
            count *= val.toInt();

            game->changeScore( count );
            ui->labelScore->clear();
            ui->labelScore->setText( QString::number( game->getScore() ) );

            ui->labelAnswer->clear();
            ui->labelAnswer->setText( game->getAnswer() );

            if ( game->getStateAnswer() ) {
                game->victory();
                QString round = "Раунд ";
                round.append( QString::number( game->getRoundNumber() ) );
                ui->labelNumberRound->clear();
                ui->labelNumberRound->setText( round );

                ui->labelQuestion->clear();
                ui->labelQuestion->setText( game->getQuestion() );

                ui->labelAnswer->clear();
                ui->labelAnswer->setText( game->getAnswer() );
            }
        }
        ui->enterCommand->clear();
    }

    if ( val != "+" && val != "П"
         && val != "Б" && ui->enterCommand->text().length() > 1 ) {
        if ( game->getCheckAnswer( ui->enterCommand->text() ) ) {

           game->changeScore( game->getCurrentValue().toInt() );
           ui->labelScore->clear();
           ui->labelScore->setText( QString::number( game->getScore() ) );

           game->victory();
           QString round = "Раунд ";
           round.append( QString::number( game->getRoundNumber() ) );
           ui->labelNumberRound->clear();
           ui->labelNumberRound->setText( round );

           ui->labelQuestion->clear();
           ui->labelQuestion->setText( game->getQuestion() );

           ui->labelAnswer->clear();
           ui->labelAnswer->setText( game->getAnswer() );

           ui->enterCommand->clear();



        }  else
            game->defeat();

    }

    ui->buttonEnter->setEnabled( false );
    ui->buttonRotateDrum->setEnabled( true );
    ui->enterCommand->setEnabled( false );

    if ( game->getRoundNumber() > 3 ) {
        ui->buttonEnter->setEnabled( false );
        ui->buttonRotateDrum->setEnabled( false );
        ui->enterCommand->setEnabled( false );
    }
}
