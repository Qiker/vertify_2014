#ifndef GAME_H
#define GAME_H

#include "drum.h"
#include "questions.h"
#include "screen.h"

class Game
{
public:
    Game();
    ~Game();

    void nextRound ();
    int getRoundNumber( void ) const;

    int getScore ( void ) const;
    void changeScore( int _score );

    int takeQuestions( const QString filename  ); //получить вопросы
    int takeValueDrum( const QString filename  ); //получить вопросы
    void addInScreen();

    void rotateDrum( void );    //вращаем барабан

    void openLetter( int num ); //открыть букву с номером num

    QString getCurrentValue( void ) const; //вернуть текущее значение барабана

    QString getQuestion( void ) const; //вернуть вопрос текущего раунда
    QString getAnswer( void ) const;   //вернуть ответ на вопрос текущего раунда
    int getCheckLetter( QString letter ) const;        //проверить букву на наличие в ответе
    bool getCheckAnswer( QString _answer ) const;
    bool getStateAnswer() const;

    void victory();
    void defeat();

    void plusCountWrong();
    int getCountWrong() const;

private:
    Drum *dr;
    Questions *qu;
    screen *sc;

    QString qu1, an1;
    QString qu2, an2;
    QString qu3, an3;

    int roundNumber;
    int score;

    int countWrong;
    //QString currentValue;
};

#endif // GAME_H
