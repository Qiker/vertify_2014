#ifndef DRUM_H
#define DRUM_H

#include <QString>

#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QFile>

#include <QHash>

#include <QTime>

class Drum
{
public:
    Drum();
    int readJsonFileValue( const QString filename );
    int parseJsonObjectValue( QJsonObject jsonObj );
    QString getValueDrum( int it );
    QString rotateDrum( void );
    QString getCurrentValueDrum( void );
private:
    QString currentValueDrum;
    QHash< int, QString > listValueDrum;
    QTime timeRand;
};

#endif // DRUM_H
