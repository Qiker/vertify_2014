#include <QString>
#include <QtTest>

#include "drum.h"

class WonderlandTest : public QObject
{
    Q_OBJECT

public:
    WonderlandTest();

private Q_SLOTS:
    //тестируем функцию readJsonFileValue
    void testDrum_readJsonFileValue();
    void testDrum_readJsonFileValue_data();

    //тестируем функцию parseJsonObjectValue
    void testDrum_parseJsonObjectValue();
    void testDrum_parseJsonObjectValue_data();

    //тестируем функцию getValueDrum
    void testDrum_getValueDrum();
    void testDrum_getValueDrum_data();

    //тестируем функцию rotateDrum
    void testDrum_rotateDrum();
    void testDrum_rotateDrum_data();
};

WonderlandTest::WonderlandTest()
{
}

//тестируем функцию readJsonFileValue
void WonderlandTest::testDrum_readJsonFileValue() {
    Drum dr;

    QFETCH( QString, data );
    QFETCH( int, rezult );
    QCOMPARE( dr.readJsonFileValue( data ), rezult );
}

void WonderlandTest::testDrum_readJsonFileValue_data() {
    QTest::addColumn< QString >( "data" );
    QTest::addColumn< int >( "rezult" );

    QTest::newRow( "readJsonFileValue_0" ) << QString( "resource/json/jsonValueDrum.txt" ) << 0;         // Файл открыт и прочитан корректно
    QTest::newRow( "readJsonFileValue_1" ) << QString( "resource/json/ERRORjsonValueDrum.txt" ) << 1;    // Файл открыт и прочитан некорректно
    QTest::newRow( "readJsonFileValue_2" ) << QString( " " ) << 2;                                       // Такого файла нет
    QTest::newRow( "readJsonFileValue_3" ) << QString( "resource/json/EMPTYjsonValueDrum.txt" ) << 1;    // Файл пустой
    QTest::newRow( "readJsonFileValue_4" ) << QString( "resource/json/NOjsonValueDrum.txt" ) << 1;       // Файл не пустой, но и не json
}
//КОНЕЦ тестируем функцию readJsonFileValue

//тестируем функцию parseJsonObjectValue
void WonderlandTest::testDrum_parseJsonObjectValue() {
    Drum dr;

    QFETCH( QJsonObject, data );
    QFETCH( int, rezult );
    QCOMPARE( dr.parseJsonObjectValue( data ), rezult );
}

void WonderlandTest::testDrum_parseJsonObjectValue_data() {
    QTest::addColumn< QJsonObject >( "data" );
    QTest::addColumn< int >( "rezult" );

    QFile json( "resource/json/jsonValueDrum.txt" ); //откроем нормальный файл и получим объект, который не будет пустым
    QJsonObject jsonObj0, jsonObj1;
    if ( json.open( QIODevice::ReadOnly ) )
    {
        QJsonParseError parseError;
        QJsonDocument jsonDoc = QJsonDocument::fromJson( json.readAll(), &parseError );
        jsonObj1 = jsonDoc.object();
        json.close();
    }

    QTest::newRow( "parseJsonObjectValue_0" ) << jsonObj0 << 1;    // если такой объект не существует
    QTest::newRow( "parseJsonObjectValue_1" ) << jsonObj1 << 0;    // если такой объект существует, и его пытались обработать
}
//КОНЕЦ тестируем функцию parseJsonObjectValue

//тестируем функцию getValueDrum
void WonderlandTest::testDrum_getValueDrum() {
    Drum dr;

    QFETCH( int, key );
    QFETCH( QString, value );

    dr.readJsonFileValue( "resource/json/jsonValueDrum.txt" );

    QCOMPARE( dr.getValueDrum( key ), value );
}

void WonderlandTest::testDrum_getValueDrum_data() {
    QTest::addColumn< int >( "key" );
    QTest::addColumn< QString >( "value" );

    QTest::newRow( "getValueDrum_0" ) << 1 << QString("35");
    QTest::newRow( "getValueDrum_1" ) << 2 << QString("П");
    QTest::newRow( "getValueDrum_2" ) << 3 << QString("30");
    QTest::newRow( "getValueDrum_3" ) << 4 << QString("25");
    QTest::newRow( "getValueDrum_4" ) << 5 << QString("+");
    QTest::newRow( "getValueDrum_5" ) << 6 << QString("20");
    QTest::newRow( "getValueDrum_6" ) << 7 << QString("15");
    QTest::newRow( "getValueDrum_7" ) << 8 << QString("Б");
    QTest::newRow( "getValueDrum_8" ) << 9 << QString("10");
    QTest::newRow( "getValueDrum_9" ) << 10 << QString("5");
    QTest::newRow( "getValueDrum_10" ) << 11 << QString("45");
    QTest::newRow( "getValueDrum_11" ) << 12 << QString("40");

    QTest::newRow( "getValueDrum_12" ) << 0 << QString("Error: incorrect input data");
    QTest::newRow( "getValueDrum_13" ) << -1 << QString("Error: incorrect input data");
    QTest::newRow( "getValueDrum_14" ) << 13 << QString("Error: incorrect input data");
}
//КОНЕЦ тестируем функцию getValueDrum

//тестируем функцию rotateDrum
void WonderlandTest::testDrum_rotateDrum() {
    Drum dr;

    QFETCH( QString, value );

    dr.readJsonFileValue( "resource/json/jsonValueDrum.txt" );
    dr.rotateDrum();

    QVERIFY( dr.getCurrentValueDrum() != value );
    //QCOMPARE( dr.getCurrentValueDrum(), value );
}

void WonderlandTest::testDrum_rotateDrum_data() {
    QTest::addColumn< QString >( "value" );

    QTest::newRow( "rotateDrum_0" ) <<  "";
}
//КОНЕЦ тестируем функцию rotateDrum



QTEST_APPLESS_MAIN(WonderlandTest)

#include "tst_wonderlandtest.moc"
