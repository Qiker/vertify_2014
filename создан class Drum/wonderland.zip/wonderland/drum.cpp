#include "drum.h"

Drum::Drum()
{
//#include "QTime"
//QTime midnight(0,0,0);
//qsrand(midnight.secsTo(QTime::currentTime()));
    timeRand = QTime( 0, 0, 0 );
    qsrand( timeRand.secsTo( QTime::currentTime() ) );

    currentValueDrum = "";
}
/**
 * @brief Drum::readJsonFileValue
 * @param ( const QString ) filename - имя файла, в котором хранятся значения полей барабана
 * @return ( int ) 0 - Файл открыт и прочитан корректно
 * @return ( int ) 1 - Файл открыт и прочитан некорректно
 * @return ( int ) 2 - Такого файла нет
 */
int Drum::readJsonFileValue(const QString filename) {
    QFile json( filename );
    if ( json.open( QIODevice::ReadOnly ) )
    {
        QJsonParseError parseError;
        QJsonDocument jsonDoc = QJsonDocument::fromJson( json.readAll(), &parseError );
        if ( parseError.error == QJsonParseError::NoError )
        {
            //if ( jsonDoc.isObject() ) {
                parseJsonObjectValue( jsonDoc.object() );
            //}
        } else return 1;
        json.close();
    } else  return 2;
    return 0;
}

/**
 * @brief Drum::parseJsonObjectValue
 * @param ( QJsonObject )jsonObj - объект, в котором хранится считанная json-конструкция
 * @return ( int )0 - если такой объект существует, и его пытались обработать
 * @return ( int )1 - если такой объект не существует
 */
int Drum::parseJsonObjectValue( QJsonObject jsonObj ) {
    if ( !jsonObj.isEmpty() ) {
        QJsonObject::iterator it;
        for ( it = jsonObj.begin(); it != jsonObj.end(); it++ )
            listValueDrum.insert( it.key().toInt(), jsonObj[it.key()].toString() );
        return 0;
    }
    return 1;
}

/**
 * @brief Drum::getValueDrum
 * @param ( int )it - индекс, для вычисления значения по индексу
 * @return ( QString ) - если нет такого значения в списке полей барабана или значения с таким индексом не существует, то выдатет "Error: incorrect input data"
 */
QString Drum::getValueDrum( int it ) {
    return (( it > listValueDrum.size() ) || ( it < 1 ) ) ?
                QString("Error: incorrect input data") :  listValueDrum.value( it );
}

/**
 * @brief Drum::rotateDrum
 * @return ( QString ) - случайное значение из списка полей барабаны, если список пуст, то вернется пустотоа
 */
QString Drum::rotateDrum() {
    if ( !listValueDrum.isEmpty() ) {
        int n = listValueDrum.size();
        currentValueDrum = listValueDrum.value( (qrand() % n + 1) );
        return currentValueDrum;
    } else
        return "";
}

/**
 * @brief Drum::getCurrentValueDrum
 * @return - вернуть текущее значение барабана
 */
QString Drum::getCurrentValueDrum() {
    return currentValueDrum;
}
