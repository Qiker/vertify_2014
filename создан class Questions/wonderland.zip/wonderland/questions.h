#ifndef QUESTIONS_H
#define QUESTIONS_H

#include <QString>

#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QFile>

#include <QHash>

#include <QTime>

class Questions
{
public:
    Questions();
    int readJsonFileQuestion( const QString filename );
    int parseJsonObjectQuestion( QJsonObject jsonObj );
    QString getQuestion( void );
    QString getAnswer( QString question );
private:
    QHash< QString, QString > listQuestions;
    QTime timeRand;
};

#endif // QUESTIONS_H
