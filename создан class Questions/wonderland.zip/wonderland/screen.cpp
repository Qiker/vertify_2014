#include "screen.h"

screen::screen()
{
}

/**
 * @brief screen::setAnswer
 * @param ( QString ) _answer - задать ответ
 */
void screen::setAnswer(QString _answer) {
    answer = _answer;

    int i = 0;

    for ( i = 0; i < answer.length(); i++ )
        answer_flag.push_back( false );
}

/**
 * @brief screen::getAnswer
 * @return ( QHash<QString, bool> )answer - вернуть ответ
 */
QString screen::getAnswer() const {
    return answer;
}

/**
 * @brief screen::getAnswerFlag
 * @return ( QList<bool> ) answer_flag - сколько букв открыто, а сколько закрыто;
 */
QList<bool> screen::getAnswerFlag() {
    return answer_flag;
}

/**
 * @brief screen::setQuestion
 * @param ( QString ) _question - задать вопрос
 */
void screen::setQuestion(QString _question) {
    question = _question;
}

/**
 * @brief screen::getQuestion
 * @return ( QString )question - вернуть вопрос
 */
QString screen::getQuestion() const {
    return question;
}

/**
 * @brief screen::checkLetter
 * @param ( QString ) letter - буква, наличие которой, нужно проверить в ответе
 * @return ( int ) numberLetters - вернуть количество найденных букв в ответе
 */
int screen::checkLetter( QString letter ) {
    int numberLetters = 0;
    int i = 0;

    for ( i = 0; i < answer.length(); i++ )
        if ( answer.at( i ) == letter ) {
            numberLetters++;
            answer_flag[i] = true;
        }

    return numberLetters;
}
/**
 * @brief screen::getStateAnswer
 * @return ( bool )stateAnswer - состояние ответа - открыто полностью или нет
 */
bool screen::getStateAnswer() const {
    int i = 0;
    for ( i = 0; i < answer_flag.size(); i++ )
        if ( answer_flag[i] == false )
            return false;

    return true;
}
