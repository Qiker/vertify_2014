#ifndef SCREEN_H
#define SCREEN_H

#include <QString>
#include <QList>

class screen
{
public:
    screen();

    void setAnswer( QString _answer );
    QString getAnswer() const;
    QList < bool > getAnswerFlag();

    void setQuestion( QString _question );
    QString getQuestion() const;

    int checkLetter( QString letter );
    bool getStateAnswer() const;
private:
    QString question;               //вопрос

    QString answer;                 //ответ
    QList < bool > answer_flag;     //если буква  открыта = true, закрыта = false >
};

#endif // SCREEN_H
